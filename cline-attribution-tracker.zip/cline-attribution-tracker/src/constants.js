// constants.js — Shared author label constants

const AUTHOR = {
  AI: "ai",
  HUMAN: "human",
  COMMENT: "comment",
  PASTE_LLM: "pl",    // Paste from LLM / AI source
  PASTE_HUMAN: "ph",  // Paste from human / unknown source
};

module.exports = { AUTHOR };
