#!/usr/bin/env node
// scripts/exportAuthorship.js
// Run this before git push (or as a pre-push git hook) to export
// the local .attribution/data.json into the format expected by the
// GitHub Actions merge workflow.
//
// Usage:
//   node scripts/exportAuthorship.js
//
// Or as a git hook, add to .git/hooks/pre-push:
//   #!/bin/sh
//   node "$(git rev-parse --show-toplevel)/scripts/exportAuthorship.js"

const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

const ATTRIBUTION_DIR = ".attribution";

function getGitInfo() {
  const run = (cmd) => {
    try { return execSync(cmd).toString().trim(); }
    catch (_) { return "unknown"; }
  };
  return {
    repo: run("git remote get-url origin"),
    branch: run("git rev-parse --abbrev-ref HEAD"),
    commit: run("git rev-parse HEAD"),
  };
}

function main() {
  const root = execSync("git rev-parse --show-toplevel").toString().trim();
  const attrDir = path.join(root, ATTRIBUTION_DIR);
  const dataPath = path.join(attrDir, "data.json");
  const outPath = path.join(attrDir, "authorship.json");

  if (!fs.existsSync(dataPath)) {
    console.log("[exportAuthorship] No attribution data found — skipping.");
    process.exit(0);
  }

  const data = JSON.parse(fs.readFileSync(dataPath, "utf8"));
  const gitInfo = getGitInfo();

  const authorship = {
    version: 1,
    generatedAt: new Date().toISOString(),
    ...gitInfo,
    files: {},
  };

  for (const [relPath, entry] of Object.entries(data.files || {})) {
    authorship.files[relPath] = {
      lineMap: entry.lineMap,
      stats: entry.stats,
    };
  }

  fs.writeFileSync(outPath, JSON.stringify(authorship, null, 2));
  console.log(`[exportAuthorship] Written: ${outPath}`);
}

main();
