#!/usr/bin/env node
// hooks/posttool.js — Cline posttool hook
//
// HOW TO CONFIGURE IN CLINE:
//   In your .clinerules file or Cline settings (JSON), add:
//
//   {
//     "hooks": {
//       "PostToolUse": [
//         {
//           "type": "command",
//           "command": "node /path/to/hooks/posttool.js"
//         }
//       ]
//     }
//   }
//
// Clears the active flag after the tool has run.
// The VS Code extension consumes the flag on the document change event,
// but this posttool hook acts as a safety clear in case the change event
// was missed (e.g., file written outside VS Code's document model).

const fs = require("fs");
const path = require("path");

const FLAG_FILE = ".cline-hook-flag.json";

async function main() {
  let input = "";
  process.stdin.setEncoding("utf8");
  for await (const chunk of process.stdin) {
    input += chunk;
  }

  // Reset the flag to inactive
  const flag = {
    active: false,
    tool: null,
    file: null,
    timestamp: Date.now(),
  };

  const flagPath = path.join(process.cwd(), FLAG_FILE);
  try {
    fs.writeFileSync(flagPath, JSON.stringify(flag, null, 2));
  } catch (_) {}

  process.exit(0);
}

main().catch(() => process.exit(0));
