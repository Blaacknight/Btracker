// clineHookWatcher.js — Watches for Cline pretool/posttool hook flag files.
//
// HOW IT WORKS:
// Cline exposes pretool and posttool hooks via hook scripts configured in
// .clinerules or cline settings. We provide two hook scripts (see /hooks/):
//   - pretool.js  → writes .cline-hook-flag.json with { active: true, tool, file }
//   - posttool.js → writes .cline-hook-flag.json with { active: false }
//
// This watcher monitors that flag file using VSCode's FileSystemWatcher.
// When active=true and tool is write_to_file or replace_in_file, the tracker
// is notified so the NEXT document change on that file is tagged as AI-authored.

const vscode = require("vscode");
const path = require("path");
const fs = require("fs");

const HOOK_FLAG_FILE = ".cline-hook-flag.json";

class ClineHookWatcher {
  constructor(workspaceRoot, tracker) {
    this.workspaceRoot = workspaceRoot;
    this.tracker = tracker;
    this.watcher = null;
    this.flagPath = path.join(workspaceRoot, HOOK_FLAG_FILE);
  }

  start() {
    if (!this.workspaceRoot) return;

    // Watch for changes to the flag file
    const pattern = new vscode.RelativePattern(
      this.workspaceRoot,
      HOOK_FLAG_FILE
    );
    this.watcher = vscode.workspace.createFileSystemWatcher(pattern);

    this.watcher.onDidChange(() => this._handleFlagChange());
    this.watcher.onDidCreate(() => this._handleFlagChange());

    console.log("[ClineHookWatcher] Watching for Cline hook flags.");
  }

  stop() {
    if (this.watcher) {
      this.watcher.dispose();
      this.watcher = null;
    }
  }

  _handleFlagChange() {
    try {
      if (!fs.existsSync(this.flagPath)) return;
      const raw = fs.readFileSync(this.flagPath, "utf8");
      const flag = JSON.parse(raw);

      // Only act on write_to_file and replace_in_file tool invocations
      const CLINE_WRITE_TOOLS = ["write_to_file", "replace_in_file"];
      if (flag.active && CLINE_WRITE_TOOLS.includes(flag.tool)) {
        // Resolve the file URI that Cline is about to write
        const targetPath = path.isAbsolute(flag.file)
          ? flag.file
          : path.join(this.workspaceRoot, flag.file);
        const uri = vscode.Uri.file(targetPath).toString();
        this.tracker.setClineFlag(uri, true);
        console.log(`[ClineHookWatcher] AI flag set for: ${flag.file}`);
      }

      // TODO: Handle posttool (active: false) to clear stale flags if needed.
      // Currently the flag is consumed on first use in tracker.resolveAuthor().
    } catch (err) {
      console.error("[ClineHookWatcher] Failed to read flag file:", err.message);
    }
  }
}

module.exports = { ClineHookWatcher };
