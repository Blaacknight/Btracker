// pasteClassifier.js — Classifies pasted text as AI-generated ('pl') or human ('ph').
//
// APPROACH: Heuristic ensemble (no external model dependency for MVP).
// Scores text across multiple signals and returns a weighted classification.
//
// For production upgrade, replace _modelScore() with a real API call to:
//   - Anthropic's classification endpoint (when available), OR
//   - A self-hosted DeBERTa fine-tuned on AI/human text pairs, OR
//   - OpenAI's text-davinci-003 log-probability endpoint (perplexity proxy)
//
// Current signals:
//   1. Burstiness — human text has higher variance in sentence length; AI is uniform
//   2. Avg line length — AI-generated code comments tend to be consistently long
//   3. Structural patterns — AI often uses numbered lists, "Note:", "Step N:", etc.
//   4. Vocabulary markers — phrases typical of LLMs
//   5. (stub) Perplexity via external model

const AUTHOR = require("./constants").AUTHOR;

class PasteClassifier {
  constructor() {
    // Weights for each signal (must sum to 1.0)
    this.weights = {
      burstiness: 0.25,
      lineLength: 0.15,
      structuralPatterns: 0.30,
      vocabMarkers: 0.20,
      modelScore: 0.10, // stub — 0.5 neutral until model is wired up
    };

    // LLM-typical phrases (case-insensitive)
    this.llmMarkers = [
      /\bsure[,!]\b/i,
      /\bof course\b/i,
      /\bcertainly\b/i,
      /\bhere(?:'s| is) (?:a |an |the )?(?:revised|updated|corrected|complete|simple|basic)/i,
      /\bplease note\b/i,
      /\bfeel free to\b/i,
      /\blet me know if\b/i,
      /\bhope this helps\b/i,
      /^\s*\d+\.\s+\w/m, // Numbered list items
      /^\s*[-*]\s+\w/m,  // Bullet lists
    ];
  }

  /**
   * Classify pasted text.
   * @param {string} text
   * @returns {{ label: 'pl' | 'ph', confidence: number }}
   */
  async classify(text) {
    if (!text || text.trim().length < 10) {
      return { label: AUTHOR.PASTE_HUMAN, confidence: 0.5 };
    }

    const scores = {
      burstiness: this._burstyScore(text),
      lineLength: this._lineLengthScore(text),
      structuralPatterns: this._structuralScore(text),
      vocabMarkers: this._vocabScore(text),
      modelScore: await this._modelScore(text), // stub: returns 0.5
    };

    // Each score is in [0,1] where 1.0 = strongly AI
    let aiScore = 0;
    for (const [key, weight] of Object.entries(this.weights)) {
      aiScore += (scores[key] || 0.5) * weight;
    }

    return {
      label: aiScore >= 0.55 ? AUTHOR.PASTE_LLM : AUTHOR.PASTE_HUMAN,
      confidence: aiScore,
      scores, // for debugging
    };
  }

  // Low burstiness (uniform sentence lengths) → AI signal
  _burstyScore(text) {
    const sentences = text.split(/[.!?]+/).filter((s) => s.trim().length > 0);
    if (sentences.length < 3) return 0.5;
    const lengths = sentences.map((s) => s.trim().length);
    const mean = lengths.reduce((a, b) => a + b, 0) / lengths.length;
    const variance =
      lengths.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / lengths.length;
    const cv = Math.sqrt(variance) / (mean || 1); // coefficient of variation
    // Low CV = uniform = AI. High CV = bursty = human.
    // Normalize: CV < 0.3 → AI score ~0.8; CV > 1.0 → AI score ~0.2
    return Math.max(0, Math.min(1, 1 - cv));
  }

  // Consistently long lines → AI signal
  _lineLengthScore(text) {
    const lines = text.split("\n").filter((l) => l.trim().length > 0);
    if (lines.length < 2) return 0.5;
    const lengths = lines.map((l) => l.length);
    const mean = lengths.reduce((a, b) => a + b, 0) / lengths.length;
    // Mean line length > 60 chars and low variance → AI
    const variance =
      lengths.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / lengths.length;
    const cv = Math.sqrt(variance) / (mean || 1);
    const longLines = mean > 60 ? 0.7 : 0.4;
    const uniform = cv < 0.4 ? 0.7 : 0.3;
    return (longLines + uniform) / 2;
  }

  // Structural AI patterns (numbered steps, bullet points, "Note:")
  _structuralScore(text) {
    const structuralPatterns = [
      /^\s*\d+\.\s/m,
      /^\s*[-*•]\s/m,
      /\bNote:\b/i,
      /\bStep \d+:/i,
      /\bExample:/i,
      /\bOutput:/i,
    ];
    const matches = structuralPatterns.filter((p) => p.test(text)).length;
    return Math.min(1, matches / 3); // 3+ structural patterns → score 1.0
  }

  // LLM vocabulary markers
  _vocabScore(text) {
    const matches = this.llmMarkers.filter((p) => p.test(text)).length;
    return Math.min(1, matches / 2);
  }

  // STUB — replace with real model API call
  // TODO: Implement using one of:
  //   Option A: POST to a self-hosted DeBERTa classifier endpoint
  //   Option B: Use OpenAI log-probabilities as a perplexity proxy
  //   Option C: Anthropic classify endpoint (when available)
  async _modelScore(_text) {
    // Neutral score until model is wired up
    return 0.5;
  }
}

module.exports = { PasteClassifier };
