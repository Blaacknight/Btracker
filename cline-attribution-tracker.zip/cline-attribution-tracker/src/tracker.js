// tracker.js — Core Attribution Tracker
// Maintains per-file character-offset attribution blocks (RLE/block-array).
// Converts to line map only at display/export time to avoid line-drift bugs.

const { AUTHOR } = require("./constants");

/**
 * Attribution block: { start: number, end: number, author: string, meta?: object }
 * 'start' and 'end' are character offsets (not line numbers).
 * Author values: 'ai' | 'human' | 'comment' | 'pl' | 'ph'
 *   pl = paste-llm, ph = paste-human
 */
class AttributionTracker {
  constructor(store, undoStack, commentDetector) {
    this.store = store;
    this.undoStack = undoStack;
    this.commentDetector = commentDetector;

    // Map<uri, Block[]> — current attribution blocks per file
    this.fileBlocks = new Map();

    // Pending paste classification: set for 200ms after a paste command fires
    // { uri, result: { label, confidence }, expiresAt }
    this.pendingPaste = null;

    // Whether the next change on a URI is cline-authored (set by ClineHookWatcher)
    this.clineFlag = new Map(); // uri -> boolean
  }

  // ── Called by ClineHookWatcher when a hook flag file is detected ──
  setClineFlag(uri, value) {
    this.clineFlag.set(uri, value);
  }

  // ── Called by extension.js paste interception ──
  setPendingPaste(uri, classificationResult) {
    this.pendingPaste = {
      uri,
      result: classificationResult,
      expiresAt: Date.now() + 200,
    };
  }

  // ── Decide author for an incoming change ──
  resolveAuthor(uri, change) {
    // 1. Cline hook flag takes highest priority
    if (this.clineFlag.get(uri)) {
      this.clineFlag.set(uri, false); // consume flag
      return AUTHOR.AI;
    }

    // 2. Pending paste within 200ms window
    if (
      this.pendingPaste &&
      this.pendingPaste.uri === uri &&
      Date.now() <= this.pendingPaste.expiresAt
    ) {
      const label = this.pendingPaste.result.label; // 'pl' or 'ph'
      this.pendingPaste = null; // consume
      return label;
    }

    // 3. Default: human keystroke
    return AUTHOR.HUMAN;
  }

  // ── Apply a VSCode ContentChange to the block array ──
  applyChange(uri, change, author, fullText) {
    if (!this.fileBlocks.has(uri)) {
      this.fileBlocks.set(uri, []);
    }

    const blocks = this.fileBlocks.get(uri);
    const { rangeOffset, rangeLength, text } = change;
    const insertLen = text.length;

    // Step 1: Check if inserted text contains comments → override author
    // commentDetector returns ranges within `text` that are comments
    // We split the block for comment ranges and tag them separately.
    const commentRanges = this.commentDetector.detect(text, this._getLanguage(uri));

    // Step 2: Remove/shrink existing blocks that overlap the deleted range
    const updated = [];
    for (const block of blocks) {
      if (block.end <= rangeOffset) {
        // Entirely before the change — keep as-is
        updated.push(block);
      } else if (block.start >= rangeOffset + rangeLength) {
        // Entirely after the deleted range — shift by net delta
        const delta = insertLen - rangeLength;
        updated.push({ ...block, start: block.start + delta, end: block.end + delta });
      } else {
        // Overlaps deletion — trim or remove
        if (block.start < rangeOffset) {
          updated.push({ ...block, end: rangeOffset }); // keep left portion
        }
        if (block.end > rangeOffset + rangeLength) {
          const delta = insertLen - rangeLength;
          updated.push({
            ...block,
            start: rangeOffset + insertLen,
            end: block.end + delta,
          }); // keep right portion
        }
        // middle portion is consumed by deletion — dropped
      }
    }

    // Step 3: Insert new blocks for the inserted text
    if (insertLen > 0) {
      if (commentRanges.length > 0) {
        // Interleave comment blocks with author blocks
        let cursor = rangeOffset;
        for (const cr of commentRanges) {
          const absStart = rangeOffset + cr.start;
          const absEnd = rangeOffset + cr.end;
          if (cursor < absStart) {
            updated.push({ start: cursor, end: absStart, author });
          }
          updated.push({ start: absStart, end: absEnd, author: AUTHOR.COMMENT });
          cursor = absEnd;
        }
        const totalEnd = rangeOffset + insertLen;
        if (cursor < totalEnd) {
          updated.push({ start: cursor, end: totalEnd, author });
        }
      } else {
        updated.push({ start: rangeOffset, end: rangeOffset + insertLen, author });
      }
    }

    // Step 4: Sort and merge adjacent blocks with same author
    updated.sort((a, b) => a.start - b.start);
    this.fileBlocks.set(uri, this._mergeBlocks(updated));

    // Persist to store
    this.store.save(uri, this.fileBlocks.get(uri), fullText);
  }

  // ── Restore from undo/redo snapshot ──
  restoreSnapshot(uri, snapshot) {
    this.fileBlocks.set(uri, snapshot.blocks);
    this.store.save(uri, snapshot.blocks, snapshot.text);
  }

  // ── Convert block array → line map for display/export ──
  // Returns: { ai: [[1,20],[45,60]], human: [[21,44]], comment: [...], pl: [...], ph: [...] }
  toLineMap(uri, fullText) {
    const blocks = this.fileBlocks.get(uri) || [];
    const lines = fullText.split("\n");
    const lineOffsets = [];
    let off = 0;
    for (const line of lines) {
      lineOffsets.push(off);
      off += line.length + 1; // +1 for \n
    }

    const charToLine = (charOffset) => {
      let lo = 0, hi = lineOffsets.length - 1;
      while (lo < hi) {
        const mid = Math.floor((lo + hi + 1) / 2);
        if (lineOffsets[mid] <= charOffset) lo = mid;
        else hi = mid - 1;
      }
      return lo + 1; // 1-indexed
    };

    const lineMap = {};
    for (const block of blocks) {
      const startLine = charToLine(block.start);
      const endLine = charToLine(Math.max(block.start, block.end - 1));
      if (!lineMap[block.author]) lineMap[block.author] = [];
      lineMap[block.author].push([startLine, endLine]);
    }

    // Merge adjacent/overlapping line ranges per author
    for (const author of Object.keys(lineMap)) {
      lineMap[author] = this._mergeLineRanges(lineMap[author]);
    }

    return lineMap;
  }

  flush() {
    // Called on deactivate — ensure all pending saves are written
    this.store.flushAll();
  }

  _mergeBlocks(blocks) {
    if (blocks.length === 0) return blocks;
    const merged = [{ ...blocks[0] }];
    for (let i = 1; i < blocks.length; i++) {
      const last = merged[merged.length - 1];
      const curr = blocks[i];
      if (curr.author === last.author && curr.start <= last.end) {
        last.end = Math.max(last.end, curr.end);
      } else {
        merged.push({ ...curr });
      }
    }
    return merged;
  }

  _mergeLineRanges(ranges) {
    if (!ranges.length) return ranges;
    ranges.sort((a, b) => a[0] - b[0]);
    const merged = [ranges[0].slice()];
    for (let i = 1; i < ranges.length; i++) {
      const last = merged[merged.length - 1];
      if (ranges[i][0] <= last[1] + 1) {
        last[1] = Math.max(last[1], ranges[i][1]);
      } else {
        merged.push(ranges[i].slice());
      }
    }
    return merged;
  }

  _getLanguage(uri) {
    // Derive language from file extension
    const ext = uri.split(".").pop().toLowerCase();
    const map = {
      js: "javascript", ts: "typescript", py: "python",
      java: "java", cpp: "cpp", c: "c", cs: "csharp",
      go: "go", rb: "ruby", rs: "rust", php: "php",
      swift: "swift", kt: "kotlin",
    };
    return map[ext] || "unknown";
  }
}

module.exports = { AttributionTracker };
