// undoStack.js — Per-file shadow undo/redo stack.
//
// Maintains deep-copied snapshots of (text, blocks) keyed by file URI.
// This runs in parallel to VSCode's native undo — we shadow it to preserve
// attribution authorship across undo/redo operations.
//
// Design note: We don't intercept VSCode's undo at the document level;
// instead, the extension registers keybinding overrides that call our stack
// BEFORE delegating to the default undo/redo command.

const MAX_STACK_DEPTH = 100;

class UndoStack {
  constructor() {
    // Map<uri, { undoStack: Snapshot[], redoStack: Snapshot[] }>
    this.stacks = new Map();
  }

  _getOrCreate(uri) {
    if (!this.stacks.has(uri)) {
      this.stacks.set(uri, { undoStack: [], redoStack: [] });
    }
    return this.stacks.get(uri);
  }

  /**
   * Push a snapshot after a change is applied.
   * @param {string} uri
   * @param {string} text — full document text at this point
   * @param {string} author — who made this change
   * @param {object[]} blocks — deep copy of current attribution blocks
   */
  push(uri, text, author, blocks) {
    const { undoStack, redoStack } = this._getOrCreate(uri);

    // Any new change clears the redo stack
    redoStack.length = 0;

    undoStack.push({
      text,
      author,
      blocks: this._deepCopy(blocks || []),
      timestamp: Date.now(),
    });

    // Cap stack depth
    if (undoStack.length > MAX_STACK_DEPTH) {
      undoStack.shift();
    }
  }

  /**
   * Pop the latest snapshot for undo.
   * Returns the snapshot to restore, or null if stack is empty.
   */
  undo(uri) {
    const { undoStack, redoStack } = this._getOrCreate(uri);
    if (undoStack.length < 2) return null; // Need at least 2 to undo (current + previous)

    const current = undoStack.pop();
    redoStack.push(current); // Save current state to redo stack

    return undoStack[undoStack.length - 1]; // Return the state to restore
  }

  /**
   * Pop from the redo stack.
   * Returns the snapshot to restore, or null if stack is empty.
   */
  redo(uri) {
    const { undoStack, redoStack } = this._getOrCreate(uri);
    if (redoStack.length === 0) return null;

    const snapshot = redoStack.pop();
    undoStack.push(snapshot);
    return snapshot;
  }

  /**
   * Peek at the current top of the undo stack without modifying it.
   */
  peek(uri) {
    const { undoStack } = this._getOrCreate(uri);
    return undoStack.length > 0 ? undoStack[undoStack.length - 1] : null;
  }

  /**
   * Clear stacks for a URI (e.g., when file is closed or reset).
   */
  clear(uri) {
    this.stacks.delete(uri);
  }

  _deepCopy(blocks) {
    return blocks.map((b) => ({ ...b }));
  }
}

module.exports = { UndoStack };
