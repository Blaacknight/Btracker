#!/usr/bin/env node
// scripts/mergeAuthorship.js — 3-way merge of authorship.json files.
//
// Called by the GitHub Actions workflow on push-to-main / PR merge.
// Also usable locally via `act` or direct invocation.
//
// Usage:
//   node mergeAuthorship.js --base base.json --ours ours.json --theirs theirs.json --out merged.json
//
// MERGE STRATEGY:
//   For each file tracked in either branch:
//     1. If only one branch touched the file → use that branch's data.
//     2. If both branches touched the file → 3-way merge line ranges:
//        a. For lines changed identically → keep (consensus).
//        b. For lines changed only in ours  → keep ours.
//        c. For lines changed only in theirs → keep theirs.
//        d. For lines changed differently in both → CONFLICT:
//           Default: prefer 'ai' over 'human' (conservative; can be changed).
//           Emit a conflict marker in the output for human review.
//
// TODO: Integrate git diff/blame to get actual line-level change sets
//       for more accurate 3-way merging (currently uses line-map diff only).

const fs = require("fs");
const path = require("path");

function parseArgs() {
  const args = process.argv.slice(2);
  const get = (flag) => {
    const i = args.indexOf(flag);
    return i !== -1 ? args[i + 1] : null;
  };
  return {
    base: get("--base"),
    ours: get("--ours"),
    theirs: get("--theirs"),
    out: get("--out") || "merged-authorship.json",
  };
}

function loadJson(filePath) {
  if (!filePath || !fs.existsSync(filePath)) return null;
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

/**
 * Merge two line maps for the same file.
 * lineMapA and lineMapB are objects like:
 *   { ai: [[1,20]], human: [[21,44]], comment: [[45,50]] }
 */
function mergeLineMaps(base, ours, theirs) {
  const allAuthors = new Set([
    ...Object.keys(ours || {}),
    ...Object.keys(theirs || {}),
  ]);

  const merged = {};
  const conflicts = [];

  for (const author of allAuthors) {
    const oursRanges = (ours || {})[author] || [];
    const theirsRanges = (theirs || {})[author] || [];

    // Simple union merge — take all ranges from both branches for this author.
    // TODO: Implement true 3-way diff using base as the common ancestor.
    // For now: union of ranges, flagging overlaps with different authors as conflicts.
    merged[author] = mergeRanges([...oursRanges, ...theirsRanges]);
  }

  // Detect conflicts: same line number attributed to different authors in ours vs theirs
  const oursFlat = flattenLineMap(ours || {});
  const theirsFlat = flattenLineMap(theirs || {});

  for (const [line, oursAuthor] of Object.entries(oursFlat)) {
    const theirsAuthor = theirsFlat[line];
    if (theirsAuthor && theirsAuthor !== oursAuthor) {
      conflicts.push({
        line: Number(line),
        ours: oursAuthor,
        theirs: theirsAuthor,
        resolved: "ai", // TODO: make configurable; default: prefer AI (conservative)
      });
      // Override to conflict resolution choice
      // Remove from both, add to resolved author
      for (const author of [oursAuthor, theirsAuthor]) {
        if (merged[author]) {
          merged[author] = merged[author].filter(
            ([start, end]) => !(start <= Number(line) && Number(line) <= end)
          );
        }
      }
      if (!merged["ai"]) merged["ai"] = [];
      merged["ai"] = mergeRanges([...merged["ai"], [Number(line), Number(line)]]);
    }
  }

  return { lineMap: merged, conflicts };
}

function flattenLineMap(lineMap) {
  // Returns Map<lineNumber, author>
  const flat = {};
  for (const [author, ranges] of Object.entries(lineMap)) {
    for (const [start, end] of ranges) {
      for (let l = start; l <= end; l++) {
        flat[l] = author;
      }
    }
  }
  return flat;
}

function mergeRanges(ranges) {
  if (!ranges.length) return ranges;
  ranges.sort((a, b) => a[0] - b[0]);
  const merged = [ranges[0].slice()];
  for (let i = 1; i < ranges.length; i++) {
    const last = merged[merged.length - 1];
    if (ranges[i][0] <= last[1] + 1) {
      last[1] = Math.max(last[1], ranges[i][1]);
    } else {
      merged.push(ranges[i].slice());
    }
  }
  return merged;
}

function computeStats(lineMap) {
  let ai = 0, human = 0, comment = 0;
  const count = (ranges) => ranges.reduce((s, [a, b]) => s + (b - a + 1), 0);
  ai = count([...(lineMap.ai || []), ...(lineMap.pl || [])]);
  human = count([...(lineMap.human || []), ...(lineMap.ph || [])]);
  comment = count(lineMap.comment || []);
  const denom = ai + human || 1;
  return {
    aiPct: Math.round((ai / denom) * 100),
    humanPct: Math.round((human / denom) * 100),
    commentPct: comment,
  };
}

function main() {
  const { base: basePath, ours: oursPath, theirs: theirsPath, out: outPath } = parseArgs();

  const baseData = loadJson(basePath);
  const oursData = loadJson(oursPath);
  const theirsData = loadJson(theirsPath);

  if (!oursData && !theirsData) {
    console.error("ERROR: At least --ours or --theirs must be provided.");
    process.exit(1);
  }

  // Start from ours as base; merge theirs on top
  const mergedFiles = {};
  const allFiles = new Set([
    ...Object.keys((oursData?.files) || {}),
    ...Object.keys((theirsData?.files) || {}),
  ]);

  const allConflicts = {};

  for (const file of allFiles) {
    const oursEntry = oursData?.files?.[file];
    const theirsEntry = theirsData?.files?.[file];
    const baseEntry = baseData?.files?.[file];

    if (!theirsEntry) {
      mergedFiles[file] = oursEntry;
      continue;
    }
    if (!oursEntry) {
      mergedFiles[file] = theirsEntry;
      continue;
    }

    // Both touched this file — 3-way merge
    const { lineMap, conflicts } = mergeLineMaps(
      baseEntry?.lineMap,
      oursEntry.lineMap,
      theirsEntry.lineMap
    );

    mergedFiles[file] = {
      lineMap,
      stats: computeStats(lineMap),
      // Don't merge raw blocks — too complex; recompute from line map
      blocks: null,
    };

    if (conflicts.length > 0) {
      allConflicts[file] = conflicts;
    }
  }

  const output = {
    version: 1,
    generatedAt: new Date().toISOString(),
    repo: oursData?.repo || theirsData?.repo || "unknown",
    branch: "merged",
    mergedFrom: {
      ours: oursData?.branch,
      theirs: theirsData?.branch,
      oursCommit: oursData?.commit,
      theirsCommit: theirsData?.commit,
    },
    conflicts: allConflicts,
    files: mergedFiles,
  };

  fs.writeFileSync(outPath, JSON.stringify(output, null, 2));

  const conflictCount = Object.keys(allConflicts).length;
  console.log(`✅ Merged authorship written to ${outPath}`);
  if (conflictCount > 0) {
    console.warn(`⚠️  ${conflictCount} file(s) had attribution conflicts (see 'conflicts' key).`);
  }
}

main();
