// attributionStore.js — Persists attribution data locally.
//
// Writes two files:
//   1. .attribution/data.json         — local only, .gitignored
//      Full block-level data per file. Used by the extension at runtime.
//
//   2. .attribution/authorship.json   — local only, .gitignored
//      Exported line-map format. Used by GitHub Action for remote merge.
//
// File format for authorship.json:
// {
//   "version": 1,
//   "generatedAt": "<ISO timestamp>",
//   "repo": "<git remote URL>",
//   "branch": "<current branch>",
//   "commit": "<HEAD sha>",
//   "files": {
//     "src/foo.js": {
//       "lineMap": {
//         "ai":      [[1, 20], [45, 60]],
//         "human":   [[21, 44]],
//         "comment": [[61, 65]],
//         "pl":      [],
//         "ph":      []
//       },
//       "stats": { "aiPct": 40, "humanPct": 55, "commentPct": 5 },
//       "blocks": [ ...raw block array... ]
//     }
//   }
// }

const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

const ATTRIBUTION_DIR = ".attribution";
const DATA_FILE = "data.json";
const AUTHORSHIP_FILE = "authorship.json";

class AttributionStore {
  constructor(workspaceRoot) {
    this.workspaceRoot = workspaceRoot || process.cwd();
    this.attrDir = path.join(this.workspaceRoot, ATTRIBUTION_DIR);
    this.dataPath = path.join(this.attrDir, DATA_FILE);
    this.authorshipPath = path.join(this.attrDir, AUTHORSHIP_FILE);

    // In-memory cache: Map<relPath, { blocks, lineMap, stats }>
    this.cache = new Map();

    this._ensureDir();
    this._loadExisting();
  }

  /**
   * Save updated blocks for a file.
   * @param {string} uri — vscode URI string
   * @param {object[]} blocks — attribution blocks (char offsets)
   * @param {string} fullText — current document text
   */
  save(uri, blocks, fullText) {
    const relPath = this._uriToRelPath(uri);
    if (!relPath) return;

    const lineMap = this._blocksToLineMap(blocks, fullText);
    const stats = this._computeStats(blocks, fullText.length);

    this.cache.set(relPath, { blocks, lineMap, stats });

    // Debounce disk writes (write at most once per 500ms per file)
    this._debouncedWrite(relPath);
  }

  /**
   * Get stats for status bar display.
   * @returns {{ aiPct: number, humanPct: number, commentPct: number }}
   */
  getStats(uri) {
    const relPath = this._uriToRelPath(uri);
    const entry = this.cache.get(relPath);
    return entry ? entry.stats : { aiPct: 0, humanPct: 0, commentPct: 0 };
  }

  /**
   * Generate a full report for a file (used in webview).
   */
  generateReport(uri) {
    const relPath = this._uriToRelPath(uri);
    const entry = this.cache.get(relPath);
    if (!entry) return { error: "No attribution data for this file." };
    return {
      file: relPath,
      lineMap: entry.lineMap,
      stats: entry.stats,
    };
  }

  /**
   * Write authorship.json — called before git push (by pre-push hook or CI).
   */
  exportAuthorship() {
    const files = {};
    for (const [relPath, entry] of this.cache.entries()) {
      files[relPath] = {
        lineMap: entry.lineMap,
        stats: entry.stats,
        blocks: entry.blocks,
      };
    }

    const payload = {
      version: 1,
      generatedAt: new Date().toISOString(),
      repo: this._getGitRemote(),
      branch: this._getGitBranch(),
      commit: this._getGitCommit(),
      files,
    };

    fs.writeFileSync(this.authorshipPath, JSON.stringify(payload, null, 2));
    return this.authorshipPath;
  }

  flushAll() {
    this._writeDataFile();
    this.exportAuthorship();
  }

  // ── Private ──────────────────────────────────────────────────────────────

  _ensureDir() {
    if (!fs.existsSync(this.attrDir)) {
      fs.mkdirSync(this.attrDir, { recursive: true });
    }
    // Ensure .attribution/ is in .gitignore
    this._addToGitignore();
  }

  _addToGitignore() {
    const gitignorePath = path.join(this.workspaceRoot, ".gitignore");
    const entry = ".attribution/";
    try {
      if (fs.existsSync(gitignorePath)) {
        const content = fs.readFileSync(gitignorePath, "utf8");
        if (!content.includes(entry)) {
          fs.appendFileSync(gitignorePath, `\n# Cline Attribution Tracker\n${entry}\n`);
        }
      } else {
        fs.writeFileSync(gitignorePath, `# Cline Attribution Tracker\n${entry}\n`);
      }
    } catch (_) {}
  }

  _loadExisting() {
    try {
      if (fs.existsSync(this.dataPath)) {
        const data = JSON.parse(fs.readFileSync(this.dataPath, "utf8"));
        for (const [relPath, entry] of Object.entries(data.files || {})) {
          this.cache.set(relPath, entry);
        }
      }
    } catch (_) {}
  }

  _writeDataFile() {
    const files = {};
    for (const [relPath, entry] of this.cache.entries()) {
      files[relPath] = entry;
    }
    try {
      fs.writeFileSync(this.dataPath, JSON.stringify({ version: 1, files }, null, 2));
    } catch (err) {
      console.error("[AttributionStore] Write failed:", err.message);
    }
  }

  // Simple debounce map
  _debounceTimers = new Map();
  _debouncedWrite(relPath) {
    if (this._debounceTimers.has(relPath)) {
      clearTimeout(this._debounceTimers.get(relPath));
    }
    this._debounceTimers.set(
      relPath,
      setTimeout(() => {
        this._writeDataFile();
        this._debounceTimers.delete(relPath);
      }, 500)
    );
  }

  _blocksToLineMap(blocks, fullText) {
    const lines = fullText.split("\n");
    const lineOffsets = [];
    let off = 0;
    for (const line of lines) {
      lineOffsets.push(off);
      off += line.length + 1;
    }

    const charToLine = (charOffset) => {
      let lo = 0, hi = lineOffsets.length - 1;
      while (lo < hi) {
        const mid = Math.floor((lo + hi + 1) / 2);
        if (lineOffsets[mid] <= charOffset) lo = mid;
        else hi = mid - 1;
      }
      return lo + 1;
    };

    const lineMap = {};
    for (const block of blocks) {
      if (!lineMap[block.author]) lineMap[block.author] = [];
      const startLine = charToLine(block.start);
      const endLine = charToLine(Math.max(block.start, block.end - 1));
      lineMap[block.author].push([startLine, endLine]);
    }

    // Merge adjacent line ranges
    for (const author of Object.keys(lineMap)) {
      lineMap[author] = this._mergeLineRanges(lineMap[author]);
    }

    return lineMap;
  }

  _computeStats(blocks, totalChars) {
    if (totalChars === 0) return { aiPct: 0, humanPct: 0, commentPct: 0 };
    const counts = { ai: 0, human: 0, comment: 0, pl: 0, ph: 0 };
    for (const block of blocks) {
      const len = block.end - block.start;
      if (block.author === "ai" || block.author === "pl") counts.ai += len;
      else if (block.author === "human" || block.author === "ph") counts.human += len;
      else if (block.author === "comment") counts.comment += len;
    }
    // Comments excluded from percentage denominator
    const denominator = counts.ai + counts.human || 1;
    return {
      aiPct: Math.round((counts.ai / denominator) * 100),
      humanPct: Math.round((counts.human / denominator) * 100),
      commentPct: Math.round((counts.comment / totalChars) * 100),
    };
  }

  _mergeLineRanges(ranges) {
    if (!ranges.length) return ranges;
    ranges.sort((a, b) => a[0] - b[0]);
    const merged = [ranges[0].slice()];
    for (let i = 1; i < ranges.length; i++) {
      const last = merged[merged.length - 1];
      if (ranges[i][0] <= last[1] + 1) {
        last[1] = Math.max(last[1], ranges[i][1]);
      } else {
        merged.push(ranges[i].slice());
      }
    }
    return merged;
  }

  _uriToRelPath(uri) {
    try {
      const filePath = uri.replace(/^file:\/\//, "");
      return path.relative(this.workspaceRoot, filePath).replace(/\\/g, "/");
    } catch (_) {
      return null;
    }
  }

  _getGitRemote() {
    try {
      return execSync("git remote get-url origin", { cwd: this.workspaceRoot })
        .toString().trim();
    } catch (_) { return "unknown"; }
  }

  _getGitBranch() {
    try {
      return execSync("git rev-parse --abbrev-ref HEAD", { cwd: this.workspaceRoot })
        .toString().trim();
    } catch (_) { return "unknown"; }
  }

  _getGitCommit() {
    try {
      return execSync("git rev-parse HEAD", { cwd: this.workspaceRoot })
        .toString().trim();
    } catch (_) { return "unknown"; }
  }
}

module.exports = { AttributionStore };
