#!/usr/bin/env node
// hooks/pretool.js — Cline pretool hook
//
// HOW TO CONFIGURE IN CLINE:
//   In your .clinerules file or Cline settings (JSON), add:
//
//   {
//     "hooks": {
//       "PreToolUse": [
//         {
//           "type": "command",
//           "command": "node /path/to/hooks/pretool.js"
//         }
//       ]
//     }
//   }
//
// Cline passes tool invocation details via stdin as JSON.
// We write a flag file that the VS Code extension watches.
//
// Flag file location: <workspace>/.cline-hook-flag.json
// Flag schema: { active: boolean, tool: string, file: string, timestamp: number }

const fs = require("fs");
const path = require("path");

const FLAG_FILE = ".cline-hook-flag.json";
const WRITE_TOOLS = ["write_to_file", "replace_in_file"];

async function main() {
  let input = "";

  // Read tool invocation JSON from stdin
  process.stdin.setEncoding("utf8");
  for await (const chunk of process.stdin) {
    input += chunk;
  }

  let toolData = {};
  try {
    toolData = JSON.parse(input);
  } catch (_) {
    // Cline may not always send JSON — silently exit
    process.exit(0);
  }

  const toolName = toolData.tool_name || toolData.tool || "";
  const filePath = toolData.params?.path || toolData.params?.file || "";

  if (WRITE_TOOLS.includes(toolName)) {
    const flag = {
      active: true,
      tool: toolName,
      file: filePath,
      timestamp: Date.now(),
    };

    // Write flag file to workspace root (CWD when Cline runs hooks)
    const flagPath = path.join(process.cwd(), FLAG_FILE);
    fs.writeFileSync(flagPath, JSON.stringify(flag, null, 2));
  }

  // Exit 0 — Cline proceeds with the tool invocation
  process.exit(0);
}

main().catch(() => process.exit(0));
