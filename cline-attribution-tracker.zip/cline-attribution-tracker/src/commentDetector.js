// commentDetector.js — Detects comment ranges in source text.
//
// Uses language-specific regex patterns. For Python triple-quoted strings,
// we treat them as potential docstrings/comments when they appear at the
// start of a module, class, or function body (statement position).
//
// Returns: Array of { start, end } character offsets within the given text.
// These are RELATIVE offsets into the passed `text` string, not file offsets.

class CommentDetector {
  constructor() {
    // Each entry: { pattern: RegExp (global, with 'd' flag for indices if available) }
    // We use exec loops for precise offset capture.
    this.languagePatterns = {
      // Single-line: // ...
      // Multi-line: /* ... */
      javascript: [
        { type: "single", pattern: /\/\/[^\n]*/g },
        { type: "multi", pattern: /\/\*[\s\S]*?\*\//g },
      ],
      typescript: [
        { type: "single", pattern: /\/\/[^\n]*/g },
        { type: "multi", pattern: /\/\*[\s\S]*?\*\//g },
      ],
      java: [
        { type: "single", pattern: /\/\/[^\n]*/g },
        { type: "multi", pattern: /\/\*[\s\S]*?\*\//g },
      ],
      cpp: [
        { type: "single", pattern: /\/\/[^\n]*/g },
        { type: "multi", pattern: /\/\*[\s\S]*?\*\//g },
      ],
      c: [
        { type: "single", pattern: /\/\/[^\n]*/g },
        { type: "multi", pattern: /\/\*[\s\S]*?\*\//g },
      ],
      csharp: [
        { type: "single", pattern: /\/\/[^\n]*/g },
        { type: "multi", pattern: /\/\*[\s\S]*?\*\//g },
      ],
      go: [
        { type: "single", pattern: /\/\/[^\n]*/g },
        { type: "multi", pattern: /\/\*[\s\S]*?\*\//g },
      ],
      rust: [
        { type: "single", pattern: /\/\/[^\n]*/g },
        { type: "multi", pattern: /\/\*[\s\S]*?\*\//g },
      ],
      swift: [
        { type: "single", pattern: /\/\/[^\n]*/g },
        { type: "multi", pattern: /\/\*[\s\S]*?\*\//g },
      ],
      kotlin: [
        { type: "single", pattern: /\/\/[^\n]*/g },
        { type: "multi", pattern: /\/\*[\s\S]*?\*\//g },
      ],
      php: [
        { type: "single", pattern: /\/\/[^\n]*/g },
        { type: "single", pattern: /#[^\n]*/g },
        { type: "multi", pattern: /\/\*[\s\S]*?\*\//g },
      ],
      ruby: [
        { type: "single", pattern: /#[^\n]*/g },
        // Ruby multi-line: =begin ... =end at start of lines
        { type: "multi", pattern: /^=begin[\s\S]*?^=end/gm },
      ],
      python: [
        { type: "single", pattern: /#[^\n]*/g },
        // Triple double-quoted strings (docstrings / block comments)
        { type: "triple", pattern: /"""[\s\S]*?"""/g },
        // Triple single-quoted strings
        { type: "triple", pattern: /'''[\s\S]*?'''/g },
      ],
      // Shell / bash / yaml
      bash: [{ type: "single", pattern: /#[^\n]*/g }],
      yaml: [{ type: "single", pattern: /#[^\n]*/g }],
      unknown: [],
    };
  }

  /**
   * Detect comment ranges in `text` for the given language.
   * @param {string} text
   * @param {string} language
   * @returns {{ start: number, end: number }[]}
   */
  detect(text, language) {
    const patterns = this.languagePatterns[language] || this.languagePatterns.unknown;
    const ranges = [];

    for (const def of patterns) {
      // Clone pattern to reset lastIndex (since they're /g flagged)
      const re = new RegExp(def.pattern.source, def.pattern.flags);
      let match;
      while ((match = re.exec(text)) !== null) {
        ranges.push({ start: match.index, end: match.index + match[0].length });
        // Prevent infinite loop on zero-length matches
        if (match[0].length === 0) re.lastIndex++;
      }
    }

    // Sort and merge overlapping ranges
    return this._mergeRanges(ranges);
  }

  _mergeRanges(ranges) {
    if (!ranges.length) return ranges;
    ranges.sort((a, b) => a.start - b.start);
    const merged = [{ ...ranges[0] }];
    for (let i = 1; i < ranges.length; i++) {
      const last = merged[merged.length - 1];
      if (ranges[i].start <= last.end) {
        last.end = Math.max(last.end, ranges[i].end);
      } else {
        merged.push({ ...ranges[i] });
      }
    }
    return merged;
  }
}

module.exports = { CommentDetector };
