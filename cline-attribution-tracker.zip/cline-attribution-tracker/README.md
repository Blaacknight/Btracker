# Cline Attribution Tracker

Tracks **human vs AI code authorship** at the character level inside VS Code, with full Cline hook integration, paste classification, undo/redo attribution, and GitHub Actions merge support.

---

## Architecture

```
src/
  extension.js          — Entry point, wires all subsystems
  tracker.js            — Core RLE/block-array engine (char-offset based)
  clineHookWatcher.js   — Watches Cline pretool/posttool flag file
  pasteClassifier.js    — Heuristic ensemble: classifies paste as pl/ph
  commentDetector.js    — Multi-language comment range detector
  undoStack.js          — Shadow undo/redo stack with attribution snapshots
  attributionStore.js   — Persists to .attribution/ (local, .gitignored)
  constants.js          — Author label constants

hooks/
  pretool.js            — Cline PreToolUse hook → writes flag file
  posttool.js           — Cline PostToolUse hook → clears flag file

scripts/
  exportAuthorship.js   — Exports .attribution/authorship.json pre-push
  mergeAuthorship.js    — 3-way merge of authorship.json (used by CI)

.github/workflows/
  merge-authorship.yml  — GitHub Actions: merges attribution on PR/push
```

---

## Author Labels

| Label    | Meaning                                      |
|----------|----------------------------------------------|
| `ai`     | Written directly by Cline (hook-confirmed)   |
| `human`  | Typed by a human                             |
| `pl`     | Pasted — classified as LLM-generated         |
| `ph`     | Pasted — classified as human-written         |
| `comment`| Comment / docstring (excluded from % calc)  |

---

## Setup

### 1. Install the Extension

```bash
# From source
cd cline-attribution-tracker
code --install-extension .
```

### 2. Configure Cline Hooks

Add to your `.clinerules` (in workspace root) or Cline's global settings JSON:

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "type": "command",
        "command": "node /absolute/path/to/hooks/pretool.js"
      }
    ],
    "PostToolUse": [
      {
        "type": "command",
        "command": "node /absolute/path/to/hooks/posttool.js"
      }
    ]
  }
}
```

### 3. Pre-push Hook (optional but recommended)

```bash
# Add to .git/hooks/pre-push
echo '#!/bin/sh\nnode "$(git rev-parse --show-toplevel)/scripts/exportAuthorship.js"' \
  > .git/hooks/pre-push
chmod +x .git/hooks/pre-push
```

### 4. GitHub Actions (remote merge)

The workflow at `.github/workflows/merge-authorship.yml` runs automatically on:
- Push to `main`
- PR merge into `main`

### 5. Local CI with `act`

```bash
# Install act: https://github.com/nektos/act
brew install act  # macOS

# Run the workflow locally
act pull_request -e .github/events/pr-merge.json
```

---

## Attribution Data Files

Both files are auto-added to `.gitignore`.

### `.attribution/data.json`
Full block-level data (character offsets). Used by the extension at runtime.

### `.attribution/authorship.json`
Line-map format. Used by the GitHub Actions merge workflow.

```json
{
  "version": 1,
  "repo": "https://github.com/org/repo.git",
  "branch": "feature/my-feature",
  "commit": "abc123...",
  "files": {
    "src/foo.js": {
      "lineMap": {
        "ai":      [[1, 20], [45, 60]],
        "human":   [[21, 44]],
        "comment": [[61, 65]]
      },
      "stats": { "aiPct": 45, "humanPct": 55, "commentPct": 8 }
    }
  }
}
```

---

## Known Limitations

1. **Paste classifier accuracy** — Heuristic-only on short snippets (<10 lines) may misclassify. Wire up `_modelScore()` in `pasteClassifier.js` for production use.
2. **Attribution 3-way merge** — Conflict resolution defaults to `ai`. Override in `mergeAuthorship.js` if needed.
3. **Triple-quoted Python strings** — Detected as comments regardless of context. A tree-sitter integration would distinguish expression-position strings from docstrings.
4. **Line map drift** — All internal storage uses char offsets. Line maps are computed on demand. Do not store line numbers as keys in data.json.
