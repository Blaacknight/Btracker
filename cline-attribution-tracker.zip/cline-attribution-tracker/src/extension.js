// extension.js — VS Code Extension Entry Point
// Registers all commands, events, and wires up subsystems.

const vscode = require("vscode");
const { AttributionTracker } = require("./tracker");
const { UndoStack } = require("./undoStack");
const { CommentDetector } = require("./commentDetector");
const { PasteClassifier } = require("./pasteClassifier");
const { AttributionStore } = require("./attributionStore");
const { ClineHookWatcher } = require("./clineHookWatcher");

let tracker = null;

function activate(context) {
  console.log("[ClineAttributionTracker] Activating...");

  const store = new AttributionStore(vscode.workspace.rootPath);
  const undoStack = new UndoStack();
  const commentDetector = new CommentDetector();
  const pasteClassifier = new PasteClassifier();
  tracker = new AttributionTracker(store, undoStack, commentDetector);

  // --- Cline Hook Watcher ---
  // Watches for the cline-hook flag file written by pretool/posttool hooks.
  const hookWatcher = new ClineHookWatcher(vscode.workspace.rootPath, tracker);
  hookWatcher.start();

  // --- Text Document Change Listener ---
  // Fires on every keystroke / programmatic edit.
  const changeDisposable = vscode.workspace.onDidChangeTextDocument((event) => {
    const uri = event.document.uri.toString();
    for (const change of event.contentChanges) {
      const author = tracker.resolveAuthor(uri, change);
      tracker.applyChange(uri, change, author, event.document.getText());
      undoStack.push(uri, event.document.getText(), author);
    }
  });

  // --- Paste Detection ---
  // Uses onDidExecuteCommand to catch paste commands.
  // 200ms window to correlate the command with the subsequent document change.
  const pasteDisposable = vscode.commands.registerCommand(
    "editor.action.clipboardPasteAction",
    async () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) return;

      const clipboardText = await vscode.env.clipboard.readText();
      const classificationResult = await pasteClassifier.classify(clipboardText);
      // classificationResult: { label: 'pl' | 'ph', confidence: number }

      // Mark the next change event within 200ms as a paste with this label.
      tracker.setPendingPaste(
        editor.document.uri.toString(),
        classificationResult
      );

      // Execute the real paste action.
      await vscode.commands.executeCommand(
        "default:editor.action.clipboardPasteAction"
      );
    }
  );

  // --- Undo/Redo Interception ---
  const undoDisposable = vscode.commands.registerCommand(
    "extension.attributedUndo",
    async () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) return;
      const uri = editor.document.uri.toString();
      const snapshot = undoStack.undo(uri);
      if (snapshot) {
        tracker.restoreSnapshot(uri, snapshot);
      }
      await vscode.commands.executeCommand("default:undo");
    }
  );

  const redoDisposable = vscode.commands.registerCommand(
    "extension.attributedRedo",
    async () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) return;
      const uri = editor.document.uri.toString();
      const snapshot = undoStack.redo(uri);
      if (snapshot) {
        tracker.restoreSnapshot(uri, snapshot);
      }
      await vscode.commands.executeCommand("default:redo");
    }
  );

  // --- Status Bar ---
  const statusBar = vscode.window.createStatusBarItem(
    vscode.StatusBarAlignment.Right,
    100
  );
  statusBar.command = "clineTracker.showAttribution";
  context.subscriptions.push(statusBar);

  const editorChangeDisposable = vscode.window.onDidChangeActiveTextEditor(
    (editor) => {
      if (editor) {
        const uri = editor.document.uri.toString();
        const stats = store.getStats(uri);
        statusBar.text = `$(person) AI: ${stats.aiPct}% Human: ${stats.humanPct}%`;
        statusBar.show();
      }
    }
  );

  // --- Show Attribution Command ---
  const showAttribDisposable = vscode.commands.registerCommand(
    "clineTracker.showAttribution",
    () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) return;
      const uri = editor.document.uri.toString();
      const report = store.generateReport(uri);
      const panel = vscode.window.createWebviewPanel(
        "attributionReport",
        "Code Attribution",
        vscode.ViewColumn.Beside,
        {}
      );
      panel.webview.html = renderReport(report);
    }
  );

  context.subscriptions.push(
    changeDisposable,
    pasteDisposable,
    undoDisposable,
    redoDisposable,
    editorChangeDisposable,
    showAttribDisposable,
    { dispose: () => hookWatcher.stop() }
  );

  console.log("[ClineAttributionTracker] Active.");
}

function deactivate() {
  if (tracker) tracker.flush();
}

function renderReport(report) {
  return `<!DOCTYPE html><html><body>
    <h2>Attribution Report</h2>
    <pre>${JSON.stringify(report, null, 2)}</pre>
  </body></html>`;
}

module.exports = { activate, deactivate };
